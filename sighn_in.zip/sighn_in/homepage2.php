<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title></title>
  </head>
  <body>
    <div class="container">
		<div class="row">

		<ul>
			<li>home </li>
      

		</ul>
		</div>

  </body>
</html>
